package com.input;

import com.output.OutputList;
import com.output.OutputRow;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Class that transforms inputs into outputs.
 *
 * @author      Marek Škreko
 * @version     %I%, %G%
 */

public class InputHandler {
    private List<InputRow> inputs;

    /**
     * Class constructor.
     * @param  inputs  list of Input Rows that needs to be transformed
     */
    public InputHandler(List<InputRow> inputs) {
        this.inputs = inputs;
    }

    /**
     * Method that transforms rows from input into desired format for output.
     * @param  timescale  which quartal is being compared, eg. 2010 Q4
     * @param  country  eg. Czech Republic
     * @return      list of rows in output format
     */
    public OutputList getOutputs(String timescale, String country) {
        List<InputRow> filteredInputs = filterByCountry(filterByTimescale(timescale),country);

        Set<String> vendorNames = allVendors(filteredInputs);
        OutputList outputList = new OutputList( country, timescale );

        vendorNames.forEach( vendorName -> {
            Double units = unitsByVendor(filteredInputs, vendorName);
            String share = shareByVendor(filteredInputs, vendorName);
            outputList.add(new OutputRow(vendorName,share,units));
        });

        return outputList;
    }

    /**
     * Filters list by given timescale.
     * @param  timescale  which quartal to filter by, eg. 2010 Q4
     * @return      list of rows after filtering by timescale
     */
    private List<InputRow> filterByTimescale(String timescale){
        List<InputRow> filteredInputs = inputs.stream().filter(row -> row.getTimescale().equals(timescale))
                .collect(Collectors.toList());

        return filteredInputs;
    }

    /**
     * Filters list by given country.
     * @param filteredInputs list that will be filtered by country
     * @param  country  which country to filter by, eg. Czech Republic
     * @return      list of rows after filtering by country
     */
    private List<InputRow> filterByCountry(List<InputRow> filteredInputs, String country){
        return filteredInputs.stream().filter(row -> row.getCountry().equals(country))
                .collect(Collectors.toList());
    }

    /**
     * Finds all vendors (without duplicity).
     * @param rows list of rows
     * @return      set of all vendors from given list of rows
     */
    private Set<String> allVendors(List<InputRow> rows){
        Set<String> allVendors = new HashSet<>();

        rows.forEach(row -> {allVendors.add(row.getVendor());});

        return allVendors;
    }

    /**
     * Finds how many units were sold by vendor.
     * @param rows list of rows
     * @param vendorName name of vendor, eg. Dell
     * @return      number of units sold (by vendor)
     */
    private Double unitsByVendor(List<InputRow> rows, String vendorName){
        rows = rows.stream()
                .filter(row -> row.getVendor().equals(vendorName))
                .collect(Collectors.toList());
        Double sum = rows.stream().mapToDouble( row -> row.getUnits()).sum();

        return sum;
    }

    /**
     * Finds how many units were sold by all vendors.
     * @param rows list of rows
     * @return      number of total units sold
     */
    private Double allUnits(List<InputRow> rows){
        Double sum = rows.stream().mapToDouble( row -> row.getUnits()).sum();

        return sum;
    }

    /**
     * Calculates share of given vendor.
     * @param rows list of rows
     * @param vendorName name of vendor, eg. Dell
     * @return      share of vendor from total, in percentage value, eg. 35%
     */
    private String shareByVendor(List<InputRow> rows, String vendorName){
        Double vendorUnits = unitsByVendor(rows, vendorName);
        Double allUnits = allUnits(rows);

        Double percentage = (vendorUnits/allUnits)*100;
        String res = String.format("%,.1f", percentage)+"%";

        return res;
    }

    public List<InputRow> getInputs() {
        return inputs;
    }
}
