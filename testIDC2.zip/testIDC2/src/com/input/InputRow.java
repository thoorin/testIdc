package com.input;

/**
 * Class that represents one row from input csv file
 *
 * @author      Marek Škreko
 * @version     %I%, %G%
 */

public class InputRow {
    private String country, vendor, timescale;
    private Double units;

    /**
     * Class constructor.
     * @param  country  first column from input file, eg. Czech Republic
     * @param  timescale second column from input file, eg. 2010 Q4
     * @param  vendor third column from input file, eg. Dell
     * @param  units fourth column from input file
     */
    public InputRow(String country, String timescale, String vendor, Double units) {
        this.country = country;
        this.vendor = vendor;
        this.timescale = timescale;
        this.units = units;
    }

    @Override
    public String toString() {
        return "Entry{" +
                "country='" + country + '\'' +
                ", vendor='" + vendor + '\'' +
                ", timescale='" + timescale + '\'' +
                ", units=" + units +
                '}';
    }

    public String getCountry() {
        return country;
    }

    public String getVendor() {
        return vendor;
    }

    public String getTimescale() { return timescale; }

    public Double getUnits() {
        return units;
    }
}
