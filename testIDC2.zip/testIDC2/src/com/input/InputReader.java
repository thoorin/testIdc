package com.input;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Class that reads input.
 *
 * @author      Marek Škreko
 * @version     %I%, %G%
 */

public class InputReader {
    /**
     * Method that reads input file. Each row is transformed into new InputRow object
     * and all created InputRow objects are stored in the list.
     * @param  filePath  complete path where input csv file is located, eg. D:/data.csv
     * @return      list of all rows
     * @throws FileNotFoundException  if the filepath is invalid
     */
    public static List<InputRow> readInput(String filePath) throws FileNotFoundException {
        File myObj = new File(filePath);
        Scanner myReader = new Scanner(myObj);

        List<InputRow> entries = new ArrayList<>();

        int i = 0;
        while (myReader.hasNextLine()) {
            if ( i == 0 ) {
                i++;
                myReader.nextLine();
                continue;
            }
            String data = myReader.nextLine();
            String[] attributes = data.split(",");

            String country = attributes[0];
            String timescale = attributes[1];
            String vendor = attributes[2];
            Double units = Double.parseDouble(attributes[3]);

            entries.add(new InputRow(country, timescale, vendor, units));
        }
        myReader.close();

        return entries;
    }
}
