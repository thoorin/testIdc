package com.output;

/**
 * Class that represents one row of desired output
 *
 * @author      Marek Škreko
 * @version     %I%, %G%
 */

public class OutputRow{
    private String name, share;
    private Double units;

    /**
     * Class constructor.
     * @param  name  name of vendor, eg. Dell
     * @param  share share of given vendor during certain timescale, eg. 40%
     * @param  units units sold during timescale
     */
    public OutputRow(String name, String share, Double units) {
        this.name = name;
        this.share = share;
        this.units = units;
    }

    @Override
    public String toString() {
        return  "name='" + name + '\'' +
                ", share='" + share + '\'' +
                ", units=" + units +
                '\n';
    }

    public String getName() {
        return name;
    }

    public Double getUnits() {
        return units;
    }

    public String getShare() {
        return share;
    }
}

