package com.output;

import java.io.FileWriter;

/**
 * Class that handles export
 *
 * @author      Marek Škreko
 * @version     %I%, %G%
 */

public class OutputHandler {
    /**
     * Method that exports given output as html into a given filepath
     * @param  filePath  path where the file will be created, eg. D:/
     * @param  fileName name of the created file
     * @param  outputList list of outputs that should be exported into HTML table
     */
    public static void exportToHtml(String filePath, String fileName, OutputList outputList){
        try {
            FileWriter myWriter = new FileWriter(filePath+fileName+".html");

            String[] timescaleCode = outputList.getTimescale().split(" ");
            StringBuilder quartal = new StringBuilder(timescaleCode[1]);
            quartal.reverse();
            timescaleCode[0] = timescaleCode[0].substring(2);
            StringBuilder sb = new StringBuilder("<html><head><style>" +
                    "table, td, th {border: 1px solid;}" +
                    "caption {text-align: left; margin-left: 3em;}" +
                    "th {background-color: #D9D9D9;}" +
                    "tfoot {background-color: #FFFF99;}" +
                    "table {border-collapse: collapse; width: 100%; text-align: center;}"+
                    "</style></head><body><table><caption>Table 1, PC Quarterly Market Share, the "+ outputList.getCountry()+", "+quartal.toString()+timescaleCode[0]+"</caption>" +
                    "<thead><tr>"+
                    "<th>"+
                    "Vendor"+
                    "</th>"+
                    "<th>"+
                    "Units"+
                    "</th>"+
                    "<th>"+
                    "Share"+
                    "</th>"+
                    "</tr></thead><tbody>");

            outputList.forEach(row -> {sb.append("<tr><td>"+row.getName()+"</td><td>"+String.format("%,.3f", row.getUnits())+"</td><td>" + row.getShare() +"</td></tr>");});
            Double sum = outputList.stream().mapToDouble(row -> row.getUnits()).sum();

            sb.append("</tbody><tfoot><tr><td>Total</td><td>"+String.format("%,.3f",sum)+"</td><td>100%</td></tr></tfoot></table></body></html>");

            myWriter.write(sb.toString());
            myWriter.close();
        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    /**
     * Method that exports given output as CSV into a given filepath
     * @param  filePath  path where the file will be created, eg. D:/
     * @param  fileName name of the created file
     * @param  outputList list of outputs that should be exported into CSV
     */
    public static void exportToCsv(String filePath, String fileName, OutputList outputList){
        try {
            FileWriter myWriter = new FileWriter(filePath+fileName+".csv");
            StringBuilder sb = new StringBuilder("Vendor,Units,Share\n");

            outputList.forEach(row -> {sb.append(row.getName()+","+row.getUnits()+","+row.getShare()+"\n");});
            Double sum = outputList.stream().mapToDouble(entry -> entry.getUnits()).sum();

            sb.append("Total,"+sum.toString()+",100%");
            myWriter.write(sb.toString());
            myWriter.close();
        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    /**
     * Method that exports given output as excel table
     * @param  filePath  path where the file will be created, eg. D:/
     * @param  fileName name of the created file
     * @param  outputList list of outputs that should be exported into xslx
     */
    public static void exportToXslx(String filePath, String fileName, OutputList outputList) {
        /**
         * Would use Apache POI library.
         *
         */
    }
}
