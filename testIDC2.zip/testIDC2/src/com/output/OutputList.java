package com.output;

import java.util.*;

/**
 * Modified list that stores objects output rows that share country and timescale.
 *
 * @author      Marek Škreko
 * @version     %I%, %G%
 */

public class OutputList extends ArrayList<OutputRow> {
    private String country, timescale;
    private Map<String,OutputRow> outputsMap = new HashMap<>();

    /**
     * Class constructor.
     * @param  country  eg. Czech Republic
     * @param  timescale  which quartal is being compared, eg. 2010 Q4
     */
    public OutputList(String country, String timescale) {
        super();
        this.country = country;
        this.timescale = timescale;
    }

    /**
     * Sorts this list alphabetically by vendor name.
     */
    public void sortByVendor(){
       Collections.sort(this, (row1, row2) -> {
            return row1.getName().compareTo(row2.getName());
       });
    }

    /**
     * Sorts this list by units sold in ascending order.
     */
    public void sortByUnits(){
        Collections.sort(this, (row1, row2) -> {
            return row1.getUnits().compareTo(row2.getUnits());
        });
    }

    /**
     * This method returns from this list, how many units were sold by given vendor.
     * @param  vendorName  name of desired vendor, eg. Dell
     * @return      number of units sold by vendor
     */
    public Double getUnits(String vendorName){
        return outputsMap.get(vendorName).getUnits();
    }

    /**
     * This method returns a share of given vendor.
     * @param  vendorName  name of desired vendor, eg. Dell
     * @return      share of the vendor, eg. 40%
     */
    public String getShare(String vendorName){
        return outputsMap.get(vendorName).getShare();
    }

    /**
     * Find in which row in the list, is given vendor located
     * @param  vendorName  name of desired vendor, eg. Dell
     * @return      number at which row vendor is located
     */
    public Integer getRowIndex(String vendorName){
        for ( OutputRow output : this ) {
            if (output.getName().equals(vendorName)){
                return this.indexOf(output) + 1;
            }
        }

        return null;
    }

    public boolean add(OutputRow row){
        boolean res = super.add(row);
        outputsMap.put(row.getName(),row);

        return res;
    }

    @Override
    public String toString() {
        return "outputs=" + super.toString();
    }

    public String getCountry() {
        return country;
    }

    public String getTimescale() {
        return timescale;
    }
}
