package com.company;

import com.input.InputHandler;
import com.input.InputReader;
import com.output.OutputHandler;
import com.output.OutputList;

public class Main {

    public static void main(String[] args) {
        // demonstration of implemented methods
        try {
            // specify your path to input csv file
            InputHandler iH = new InputHandler(InputReader.readInput("D:/data.csv"));
            OutputList outputList = iH.getOutputs("2010 Q3", "Czech Republic");
            OutputList outputList2 = iH.getOutputs("2010 Q3", "Slovakia");

            System.out.println(outputList.getUnits("Apple"));
            System.out.println(outputList.getShare("Apple"));
            System.out.println(outputList.getRowIndex("Apple"));

            System.out.println(outputList);
            outputList.sortByUnits();
            System.out.println(outputList);
            outputList.sortByVendor();
            System.out.println(outputList);

            System.out.println(outputList2);

            // specify path and fileName where the output file will be saved
            OutputHandler.exportToHtml("D:/", "dataTable", outputList);
            OutputHandler.exportToCsv("D:/", "dataTable", outputList);
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }
}
